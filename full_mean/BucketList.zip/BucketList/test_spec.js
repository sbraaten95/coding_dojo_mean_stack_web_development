var expect = require('chai').expect;

describe('Mocha TDD Framework', function() {
	it('should work', function(){
		expect(2).to.be.above(1);
	});
});